export class Weather {

    mainInfo: string;
    description: string;
}