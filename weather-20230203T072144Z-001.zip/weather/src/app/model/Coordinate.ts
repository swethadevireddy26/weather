export class Coordinate {
    latitude: number;
    longitude: number;
}   