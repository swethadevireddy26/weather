import { ShowWeekDayPipe } from './show-week-day.pipe';

describe('ShowWeekDayPipe', () => {
  it('create an instance', () => {
    const pipe = new ShowWeekDayPipe();
    expect(pipe).toBeTruthy();
  });
});
