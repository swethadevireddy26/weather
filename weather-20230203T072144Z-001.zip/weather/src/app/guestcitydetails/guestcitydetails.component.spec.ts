import { ComponentFixture, TestBed } from '@angular/core/testing';

import { GuestCityWeatherComponent } from './guestcitydetails.component';

describe('DashboardComponent', () => {
  let component: GuestCityWeatherComponent;
  let fixture: ComponentFixture<GuestCityWeatherComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ GuestCityWeatherComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(GuestCityWeatherComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
