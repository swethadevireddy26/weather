// import { Component, OnInit } from '@angular/core';
// import { ActivatedRoute, ParamMap, Router } from '@angular/router';
// import { Observable } from 'rxjs';
// import { CityWeather } from '../model/cityWeather/CityWeather';
// import { WatchListService } from '../service/watch-list.service';
// import { WeatherUtil } from '../util/weather.util';

// @Component({
//   selector: 'guest-city-details',
//   templateUrl: './guestcitydetails.component.html',
//   styleUrls: ['./guestcitydetails.component.css']
// })
// export class GuestCityWeatherComponent implements OnInit {

//   util: WeatherUtil = new WeatherUtil();
//   city: string | undefined;
//   country: string | undefined;
//   cityWeather: CityWeather;
//   weekday = new Date().getDay();
//   flag = false;
//   alreadyflag= false;

//   constructor(route: ActivatedRoute, private service: WatchListService, private router: Router) {
//     const observer = {
//       next: (map: ParamMap) => {
//         this.city = map.get("city");
//         this.country = map.get("country");
//         this.searchResult();
//       }
//     }
//     const observable: Observable<ParamMap> = route.paramMap;
//     observable.subscribe(observer);
//   }

//   ngOnInit(): void {
//   }

//   searchResult() {
//     this.service.search(this.city, this.country).subscribe(data => {
//       this.cityWeather = this.util.toCityWeather(data);
//       console.log(this.cityWeather);
//     })
//   }



//    {
// addWeatherToWatchListdb()
//     const obser = {
//       next: (data: CityWeather) => {
//           console.log(data);
//           this.flag = true;
//           setInterval(() => {
//           this.flag = false
//             }, 2000);
//       },
//       error:(err:Error)=>{
//         this.alreadyflag = true;
//           setInterval(() => {
//           this.alreadyflag = false
//             }, 2000);
//       }
//     }


//     const observer =  this.service.addWeather(this.cityWeather);
//     observer.subscribe(obser);
//   }

// }
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, ParamMap, Router } from '@angular/router';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Observable } from 'rxjs';
import { CityWeather } from '../model/cityWeather/CityWeather';
import { WatchListService } from '../service/watch-list.service';
import { WeatherUtil } from '../util/weather.util';

@Component({
  selector: 'guest-city-details',
  templateUrl: './guestcitydetails.component.html',
  styleUrls: ['./guestcitydetails.component.css']
})
export class GuestCityWeatherComponent implements OnInit {

  util: WeatherUtil = new WeatherUtil();
  city: string | undefined;
  country: string | undefined;
  cityWeather: CityWeather;
  weekday = new Date().getDay();
  flag = false;
  alreadyflag= false;
  cityControl:FormControl;
  countryControl :FormControl ; 
  search:FormGroup;

  
  path:string = `city-weather/guest/${localStorage.getItem('currentCity')}/null`
  constructor(route: ActivatedRoute, private fb:FormBuilder, private router: Router,private service: WatchListService) {
    const observer = {
      next: (map: ParamMap) => {
        this.city = map.get("city");
        this.country = map.get("country");
        this.searchResult();
      }
    }
    const observable: Observable<ParamMap> = route.paramMap;
    observable.subscribe(observer);
  }


  ngOnInit(): void {
    this.cityControl = this.fb.control('',[Validators.required]);
    this.countryControl = this.fb.control('',[Validators.required]);
    this.search = this.fb.group({
      cityControl:this.cityControl,
      countryControl:this.countryControl
    });
  }
  addWeatherToWatchListdb() {

    const obser = {
      next: (data: CityWeather) => {
          console.log(data);
          this.flag = true;
          setInterval(() => {
          this.flag = false
            }, 2000);
      },
      error:(err:Error)=>{
        this.alreadyflag = true;
          setInterval(() => {
          this.alreadyflag = false
            }, 2000);
      }
    }


    const observer =  this.service.addWeather(this.cityWeather);
    observer.subscribe(obser);
  }

  searchResult() {
    this.service.search(this.city, this.country).subscribe(data => {
      this.cityWeather = this.util.toCityWeather(data);
      console.log(this.cityWeather);
    })
  }


  searchValue(){
    const city = this.cityControl.value;
    const country = this.countryControl.value;
    const url = `/city-weather/guest/${city}/${country}`; 
    this.router.navigate([url]);
    this.search.reset();
  }

}