package com.watchList.exception;

public class AlreadyExistInWatchListException extends Exception {
    public AlreadyExistInWatchListException(String message){
        super(message);
    }
}
